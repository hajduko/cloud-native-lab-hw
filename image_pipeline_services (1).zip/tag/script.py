
import os
import redis
import json
from minio import Minio
import numpy as np
import cv2
import copy

COLORS = np.random.uniform(0, 255, size=(21, 3))

# Init Redis
redis_host = os.getenv("REDIS_HOST", "localhost")
redis_port = int(os.getenv("REDIS_PORT", "6379"))
r = redis.Redis(host=redis_host, port=redis_port, decode_responses=True)

# Init MinIO
minio_client = Minio(
    os.getenv("MINIO_ENDPOINT", "localhost:9000"),
    access_key=os.getenv("MINIO_ACCESS_KEY", "minioadmin"),
    secret_key=os.getenv("MINIO_SECRET_KEY", "minioadmin"),
    secure=False
)
bucket = os.getenv("MINIO_BUCKET", "images")

queue = "tag"

while True:
    _, msg = r.blpop(queue)
    data = json.loads(msg)
    in_path = data["original_image_path"]
    labels_and_coords = data["labels_and_coords"]
    out_path = in_path.replace("original", "tagged")

    img_data = minio_client.get_object(bucket, in_path).read()
    arr = np.frombuffer(img_data, np.uint8)
    origin_image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    image = copy.deepcopy(origin_image)

    for label_and_coord in labels_and_coords:
        label = label_and_coord["label"]["name"]
        index = label_and_coord["label"]["index"]
        startY = label_and_coord["startY"]
        cv2.rectangle(image,
                      (label_and_coord["startX"], startY),
                      (label_and_coord["endX"], label_and_coord["endY"]),
                      COLORS[index], 2)
        y = startY
        cv2.putText(image, label, (label_and_coord["startX"], y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLORS[index], 2)

    _, buffer = cv2.imencode('.jpg', image)
    minio_client.put_object(bucket, out_path, buffer.tobytes(), len(buffer), content_type="image/jpeg")
    print(f"[INFO] Tagged image saved to MinIO: {out_path}")
