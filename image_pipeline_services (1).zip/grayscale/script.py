
import os
import redis
import json
from minio import Minio
import cv2
import numpy as np

# Init Redis
redis_host = os.getenv("REDIS_HOST", "localhost")
redis_port = int(os.getenv("REDIS_PORT", "6379"))
r = redis.Redis(host=redis_host, port=redis_port, decode_responses=True)

# Init MinIO
minio_client = Minio(
    os.getenv("MINIO_ENDPOINT", "localhost:9000"),
    access_key=os.getenv("MINIO_ACCESS_KEY", "minioadmin"),
    secret_key=os.getenv("MINIO_SECRET_KEY", "minioadmin"),
    secure=False
)
bucket = os.getenv("MINIO_BUCKET", "images")

queue = "grayscale"

while True:
    _, msg = r.blpop(queue)
    data = json.loads(msg)
    in_path = data["resized_image_path"]
    out_path = in_path.replace("resized", "grayscale")

    img_data = minio_client.get_object(bucket, in_path).read()
    img_array = np.frombuffer(img_data, np.uint8)
    image = cv2.imdecode(img_array, cv2.IMREAD_COLOR)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, buffer = cv2.imencode('.jpg', gray)
    minio_client.put_object(bucket, out_path, buffer.tobytes(), len(buffer), content_type="image/jpeg")

    data["grayscale_image_path"] = out_path
    r.rpush("objectdetect", json.dumps(data))
