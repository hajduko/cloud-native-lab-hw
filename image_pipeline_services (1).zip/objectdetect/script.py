
import os
import redis
import json
from minio import Minio
import numpy as np
import cv2

# Load model
CLASSES = ["background", "aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat", "chair",
           "cow", "diningtable", "dog", "horse", "motorbike", "person", "pottedplant", "sheep", "sofa",
           "train", "tvmonitor"]
CONFIDENCE_MIN = 0.4
net = cv2.dnn.readNetFromCaffe("MobileNetSSD_deploy.prototxt", "MobileNetSSD_deploy.caffemodel")

# Init Redis
redis_host = os.getenv("REDIS_HOST", "localhost")
redis_port = int(os.getenv("REDIS_PORT", "6379"))
r = redis.Redis(host=redis_host, port=redis_port, decode_responses=True)

# Init MinIO
minio_client = Minio(
    os.getenv("MINIO_ENDPOINT", "localhost:9000"),
    access_key=os.getenv("MINIO_ACCESS_KEY", "minioadmin"),
    secret_key=os.getenv("MINIO_SECRET_KEY", "minioadmin"),
    secure=False
)
bucket = os.getenv("MINIO_BUCKET", "images")

queue = "objectdetect"

while True:
    _, msg = r.blpop(queue)
    data = json.loads(msg)
    in_path = data["grayscale_image_path"]
    orig_path = data["original_image_path"]
    origin_h = data["origin_h"]
    origin_w = data["origin_w"]

    img_data = minio_client.get_object(bucket, in_path).read()
    arr = np.frombuffer(img_data, np.uint8)
    gray_img = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)

    image = cv2.cvtColor(gray_img, cv2.COLOR_GRAY2BGR)
    (height, width) = image.shape[:2]
    blob = cv2.dnn.blobFromImage(image, 0.007843, (height, width), 127.5)
    net.setInput(blob)
    detections = net.forward()

    labels_and_coords = []
    for i in np.arange(0, detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > CONFIDENCE_MIN:
            idx = int(detections[0, 0, i, 1])
            box = detections[0, 0, i, 3:7] * np.array([origin_w, origin_h, origin_w, origin_h])
            (startX, startY, endX, endY) = box.astype("int")
            labels_and_coords.append({
                "startX": int(startX),
                "startY": int(startY),
                "endX": int(endX),
                "endY": int(endY),
                "label": {"name": CLASSES[idx], "index": int(idx)},
                "confidence": float(confidence)
            })

    data["labels_and_coords"] = labels_and_coords
    r.rpush("tag", json.dumps(data))
